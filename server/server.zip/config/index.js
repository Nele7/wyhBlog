//常量

module.exports = {
    PAGECOUNT : 10,  //每页文章条数
}